# Course Summary Overwrite
Moodle Admin Tool.  
Overwrites the course summaries for every course in a particular category.  

Created by Colin Bernard (https://wcln.ca).
